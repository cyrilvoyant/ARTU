function [K,alpha] = K_alpha(corrh,corr2h,Q)

%K_alpha input corrh  the autocorrelation at lag h, rho(h) (-1<..<1)
%              corr2h the autocorrelation at lag 2h, rho(2h) (-1<..<1)
%              Q      the measurement quality, through R = sigma_v^2 / sigma_x^2 (noise variance over signal variance,
%                     Voyant et al., ARTU paper, Section 2.2.1): Q=0 for R=0 (perfect measurement), Q=1 for R=0.01,
%                     Q=2 for R=0.05, Q=3 for R=0.1. The values 0.01, 0.05 and 0.1 of R are also accepted directly.
%                     Q=2 (R=0.05) is the value used in the paper when the measurement error is not known (default).
%K_alpha output K     the K value of the ARTU method
%               alpha the alpha value of the ARTU method
%Example (paper, h=1): [K,alpha] = K_alpha(0.4,0.3,2) gives K = -0.25 and alpha = 0.59.
%The tables M(R) (files R*.mat) are tabulated on a grid of step 0.05 in rho(h) and rho(2h), interpolated here.

if nargin < 3 || isempty(Q)
    Q = 2;
end
if Q == 0
    load('R0.mat');
elseif Q == 1 || Q == 0.01
    load('R0.01.mat');
elseif Q == 2 || Q == 0.05
    load('R0.05.mat');
elseif Q == 3 || Q == 0.1
    load('R0.1.mat');
else
    error('K_alpha:Q', 'Q must be 0, 1, 2 or 3 (or R = 0.01, 0.05 or 0.1).');
end

[Y]=meshgrid(-1:0.05:1);
X=Y';

K = interp2(Y,X,res_K,corr2h,corrh);
alpha = interp2(Y,X,res_a,corr2h,corrh);

end
